chrome.example.onFinished.addListener((msg) => { alert(msg) })
chrome.example.start((msg) => { alert(msg) })